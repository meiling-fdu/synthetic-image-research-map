import csv
import json
import tempfile
import unittest
from collections import Counter
from pathlib import Path

from scripts.paper_taxonomy_registry import (
    PaperTaxonomyRegistryError,
    apply_paper_taxonomy_registry,
    read_paper_taxonomy_registry,
)
from scripts.paper_exclusions import (
    all_identity_keys,
    build_active_exclusion_index,
    read_exclusion_rows,
    record_is_excluded,
)
from scripts.migrate_paper_taxonomy import build_registry, write_registry


ROOT = Path(__file__).resolve().parents[1]
SCOPE_EXCLUDED_TITLES = {
    "Can Model Attribution Bridge AI's Accountability Gap in Safety-Critical Domains?",
    "Cascade learning from adversarial synthetic images for accurate pupil detection",
    "DynEval: Holistic Evaluations of T2I Generative Models in the Wild",
    "DeepArt: A Benchmark to Advance Fidelity Research in AI-Generated Content",
    "How spammers and scammers leverage AI-generated images on Facebook for audience growth",
    "Does an emotional connection to art really require a human artist? Emotion and intentionality responses to AI- versus human-created art and impact on aesthetic experience",
}


class PaperTaxonomyMigrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with (ROOT / "data/curated/papers.csv").open(encoding="utf-8", newline="") as handle:
            cls.curated_papers = list(csv.DictReader(handle))
        cls.registry = read_paper_taxonomy_registry(ROOT / "data/curated/paper_taxonomy.csv")
        cls.public = json.loads((ROOT / "web/data/public_preview_papers.json").read_text(encoding="utf-8"))["records"]
        cls.markers = json.loads((ROOT / "web/data/public_preview_map_data.json").read_text(encoding="utf-8"))["records"]

    def test_registry_covers_the_reconciled_public_corpus_not_papers_csv(self):
        self.assertEqual(479, len(self.curated_papers))
        self.assertEqual(666, len(self.registry))
        self.assertEqual(623, len(self.public))
        self.assertEqual(468, sum(bool(row["paper_id"]) for row in self.registry))
        self.assertEqual(198, sum(not row["paper_id"] for row in self.registry))
        summary = apply_paper_taxonomy_registry(
            [dict(row) for row in self.public],
            [dict(row) for row in self.markers],
            self.registry,
            read_exclusion_rows(),
        )
        self.assertEqual(623, summary["public_papers_matched"])
        self.assertEqual(43, summary["registry_rows_suppressed_by_active_exclusion"])
        self.assertEqual(1392, summary["map_records_matched"])

    def test_curated_only_historical_taxonomy_rows_are_actively_excluded(self):
        public_ids = {row.get("paper_id") for row in self.public if row.get("paper_id")}
        curated_ids = {row["paper_id"] for row in self.curated_papers}
        curated_only = curated_ids - public_ids
        self.assertEqual(23, len(curated_only))
        historical = [
            row
            for row in self.registry
            if row.get("paper_id") in curated_only
        ]
        active = build_active_exclusion_index(read_exclusion_rows())
        # Twelve internally curated migration rows are suppressed; the
        # thirteenth internal-ID candidate is the blocked LADLE-MM conflict and
        # remains public.
        self.assertEqual(12, len(historical))
        self.assertTrue(all(record_is_excluded(row, active) for row in historical))

    def test_historical_taxonomy_row_without_public_or_exclusion_still_fails(self):
        with self.assertRaisesRegex(
            PaperTaxonomyRegistryError,
            "without an active exclusion",
        ):
            apply_paper_taxonomy_registry(
                [dict(row) for row in self.public],
                [dict(row) for row in self.markers],
                self.registry,
                [],
            )

    def test_title_only_exclusion_cannot_account_for_unmatched_taxonomy(self):
        orphan = dict(self.registry[0])
        orphan.update(taxonomy_id="taxonomy:unmatched", title="Unmatched taxonomy fixture", year="2026")
        for key in ("paper_id", "doi", "arxiv_id", "openalex_url"):
            orphan[key] = ""
        exclusion = {"title": orphan["title"], "year": "2026", "is_active": "true"}
        with self.assertRaisesRegex(PaperTaxonomyRegistryError, "without an active exclusion"):
            apply_paper_taxonomy_registry(
                [dict(row) for row in self.public],
                [dict(row) for row in self.markers],
                [*self.registry, orphan], [*read_exclusion_rows(), exclusion],
            )

    def test_focused_scope_exclusions_leave_public_and_taxonomy_outputs(self):
        self.assertTrue(
            SCOPE_EXCLUDED_TITLES.isdisjoint(row["title"] for row in self.registry)
        )
        self.assertTrue(
            SCOPE_EXCLUDED_TITLES.isdisjoint(row["title"] for row in self.public)
        )
        self.assertTrue(
            SCOPE_EXCLUDED_TITLES.isdisjoint(row["title"] for row in self.markers)
        )

    def test_registry_has_independent_dimension_review_evidence(self):
        for row in self.registry:
            for dimension in ("tasks", "image_scopes", "research_types"):
                self.assertIn(row[f"{dimension}_status"], {"reviewed", "needs_review"})
                self.assertTrue(row[f"{dimension}_evidence_tier"])
                self.assertTrue(row[f"{dimension}_evidence_source"])
                self.assertTrue(row[f"{dimension}_evidence_excerpt"])
                if row[f"{dimension}_status"] == "needs_review":
                    self.assertTrue(row[f"{dimension}_review_reason"])
            expected = "needs_review" if any(
                row[f"{dimension}_status"] == "needs_review"
                for dimension in ("tasks", "image_scopes", "research_types")
            ) else "reviewed"
            self.assertEqual(expected, row["taxonomy_status"])

    def test_public_json_uses_arrays_and_exposes_taxonomy_review_separately(self):
        for record in [*self.public, *self.markers]:
            for field in ("tasks", "image_scopes", "research_types"):
                self.assertIsInstance(record.get(field), list)
            self.assertIn(record["taxonomy_status"], {"reviewed", "needs_review"})
            self.assertEqual(
                {"tasks", "image_scopes", "research_types"},
                set(record["taxonomy_review"]),
            )
            self.assertTrue({"task", "paper_categories", "entry_type"}.isdisjoint(record))

    def test_localization_has_explicit_task_or_evaluation_evidence(self):
        localized = [row for row in self.registry if "localization" in row["tasks"].split(";")]
        self.assertEqual(38, len(localized))
        for row in localized:
            evidence = row["tasks_evidence_excerpt"].casefold()
            self.assertTrue(any(term in evidence for term in ("local", "segmentation", "iou")), row["title"])

    def test_generative_editing_has_source_modification_evidence(self):
        edited = [row for row in self.registry if "generative_editing" in row["image_scopes"].split(";")]
        self.assertEqual(47, len(edited))
        for row in edited:
            evidence = row["image_scopes_evidence_excerpt"].casefold()
            self.assertTrue(
                any(term in evidence for term in ("inpaint", "edit", "augmented", "stargan", "diffusion")),
                row["title"],
            )

    def test_expected_counts_and_review_counts(self):
        expected = {
            "tasks": Counter(detection=622, source_attribution=82, localization=38),
            "image_scopes": Counter(fully_generated=560, generative_editing=47, deepfake=176, traditional_manipulation=23),
            "research_types": Counter(method=572, dataset=133, benchmark=82, survey=24, analysis_study=76),
        }
        for field, counts in expected.items():
            actual = Counter(value for row in self.registry for value in row[field].split(";") if value)
            self.assertEqual(counts, actual)
        self.assertEqual(
            {"tasks": 0, "image_scopes": 0, "research_types": 0},
            {
                field: sum(row[f"{field}_status"] == "needs_review" for row in self.registry)
                for field in ("tasks", "image_scopes", "research_types")
            },
        )
        self.assertEqual(0, sum(row["taxonomy_status"] == "needs_review" for row in self.registry))

    def test_current_round_trip_preserves_all_666_rows_and_43_excluded_rows(self):
        rebuilt = build_registry(
            ROOT / "web/data/public_preview_papers.json",
            ROOT / "data/curated/paper_taxonomy.csv",
        )
        with tempfile.TemporaryDirectory() as directory:
            serialized = Path(directory) / "taxonomy.csv"
            write_registry(rebuilt, serialized)
            reread = read_paper_taxonomy_registry(serialized)
            self.assertEqual(self.registry, reread)
            self.assertEqual(rebuilt, build_registry(
                ROOT / "web/data/public_preview_papers.json", serialized
            ))
            summary = apply_paper_taxonomy_registry(
                [dict(row) for row in self.public],
                [dict(row) for row in self.markers], reread, read_exclusion_rows()
            )
            self.assertEqual(623, summary["public_papers_matched"])
            self.assertEqual(43, summary["registry_rows_suppressed_by_active_exclusion"])
        dimensions = ("tasks", "image_scopes", "research_types")
        active = build_active_exclusion_index(read_exclusion_rows())
        expected = {row["taxonomy_id"]: row for row in self.registry}
        excluded = [row for row in rebuilt if record_is_excluded(row, active)]
        self.assertEqual(666, len(rebuilt))
        self.assertEqual(43, len(excluded))
        self.assertTrue(
            all(
                any(
                    not key.startswith("title_year:")
                    for key in all_identity_keys(row)
                )
                for row in excluded
            )
        )
        self.assertEqual(set(expected), {row["taxonomy_id"] for row in rebuilt})
        self.assertEqual(
            [row["taxonomy_id"] for row in self.registry],
            [row["taxonomy_id"] for row in rebuilt],
        )
        for row in rebuilt:
            prior = expected[row["taxonomy_id"]]
            for dimension in dimensions:
                self.assertEqual(prior[dimension], row[dimension])
                self.assertEqual(prior[f"{dimension}_status"], row[f"{dimension}_status"])
                self.assertEqual(prior[f"{dimension}_evidence_source"], row[f"{dimension}_evidence_source"])

    def test_rebuild_rejects_nonpublic_prior_rows_without_active_exclusions(self):
        with self.assertRaisesRegex(
            ValueError,
            "without an active strong-identity exclusion",
        ):
            build_registry(
                ROOT / "web/data/public_preview_papers.json",
                ROOT / "data/curated/paper_taxonomy.csv",
                exclusions_path=None,
            )


class FrontendTaxonomyContractTests(unittest.TestCase):
    def test_filters_details_stats_and_deep_links_use_new_dimensions(self):
        html = (ROOT / "web/index.html").read_text(encoding="utf-8")
        app = (ROOT / "web/app.js").read_text(encoding="utf-8")
        for control in ("task-filter", "image-scope-filter", "research-type-filter"):
            self.assertIn(f'id="{control}"', html)
        for parameter in ('"tasks"', '"image_scopes"', '"research_types"'):
            self.assertIn(parameter, app)
        self.assertIn("Dimension counts overlap", app)
        self.assertIn("Paper taxonomy", app)


if __name__ == "__main__":
    unittest.main()
