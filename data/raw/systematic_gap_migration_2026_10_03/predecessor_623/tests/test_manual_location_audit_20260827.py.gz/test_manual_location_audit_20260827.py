"""Durable regressions for the independently verified Admin location batch."""

import csv
import json
from pathlib import Path

import pytest

from scripts.curated_locations import location_review_payload, normalized_location_key
from scripts.curated_mappings import load_mappings
from scripts.frozen_predecessor_666 import (
    predecessor_exclusion_rows,
    predecessor_map_records,
)
from scripts.report_public_relationship_location_completeness import valid_coordinates
from scripts.validate_curated_database import validate_institution_entities

ROOT = Path(__file__).resolve().parents[1]
CURATED = ROOT / "data/curated"
PREDECESSOR_MAP_RECORDS = predecessor_map_records()
PREDECESSOR_EXCLUSION_ROWS = predecessor_exclusion_rows()


def rows(name):
    with (CURATED / (name + ".csv")).open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def locations(key):
    return [r for r in rows("institution_locations") if r["institution_id"] == "institution:" + key]


def markers(key):
    return [
        row
        for row in PREDECESSOR_MAP_RECORDS
        if row.get("institution_id") == "institution:" + key
    ]


@pytest.mark.parametrize("key,city,lat,lon,rejected", [
    ("cc8345310a2617a6", "Durban", -29.852922926731402, 31.005967931251714, (-29.6458441, 30.3501321)),
    ("128d207ba007d9d7", "Dehradun", 30.2680182, 77.9961185, (30.2726626, 78.0003415)),
    ("d04d3d98b14dcbc7", "Bellville", -33.9318380, 18.6421452, (-33.9153709, 18.6339742)),
])
def test_corrected_campus_not_wrong_feature(key, city, lat, lon, rejected):
    location, = locations(key)
    assert location["city"] == city
    assert (float(location["lat"]), float(location["lon"])) == pytest.approx((lat, lon))
    current = [m for m in markers(key) if m.get("mapping_id")]
    assert current
    assert all((m["lat"], m["lon"]) != rejected for m in current)
    assert all((m["lat"], m["lon"]) == pytest.approx((lat, lon)) for m in current)


def test_graphic_era_and_hill_keep_distinct_identities_and_sites():
    assert locations("128d207ba007d9d7")[0]["lat"] != locations("803f64e5aa26f523")[0]["lat"]
    entities = {r["institution_id"]: r for r in rows("institutions")}
    for key in ("128d207ba007d9d7", "803f64e5aa26f523"):
        assert entities["institution:" + key]["institution_status"] == "active"


def test_deakin_two_campuses_and_exact_author_groups_not_bus_stop():
    campus = {r["city"]: r for r in locations("30e93da233b7eeef")}
    assert set(campus) == {"Burwood", "Waurn Ponds"}
    assert all((r["lat"], r["lon"]) != ("-37.8501813", "145.1151967") for r in campus.values())
    mappings = {r["institution_city"]: r for r in rows("author_institution_mappings") if r["paper_id"] == "curated:c071c25bc2957d78569b" and r["institution_id"] == "institution:30e93da233b7eeef"}
    assert mappings["Burwood"]["institution_authors"] == "Thanh Thi Nguyen; Dung Tien Nguyen; Duc Thanh Nguyen"
    assert mappings["Waurn Ponds"]["institution_authors"] == "Saeid Nahavandi"
    assert {r["affiliation_order"] for r in mappings.values()} == {"1", "4"}
    for city, mapping in mappings.items():
        assert mapping["location_id"] == campus[city]["location_id"]
        exported = next(m for m in markers("30e93da233b7eeef") if m.get("mapping_id") == mapping["mapping_id"])
        assert exported["city"] == city
        assert exported["institution_authors"] == mapping["institution_authors"].split("; ")


def test_nirma_duplicate_consolidation_has_redirect_and_no_lost_mapping():
    location, = locations("af28dc8d805f8918")
    assert location["city"] == "Ahmedabad"
    audits = rows("institution_audit_log")
    assert any(r["action"] == "location_merge" and r["previous_location_id"] == "location:dec1e7f84933bb0b0327" and r["location_id"] == location["location_id"] for r in audits)
    assert len([r for r in rows("author_institution_mappings") if r["institution_id"] == location["institution_id"] and r["mapping_status"] == "active"]) == 2


def test_cuhk_merge_keeps_user_campus_alias_abbreviation_and_lineage():
    entities = {r["institution_id"]: r for r in rows("institutions")}
    survivor = "institution:ff4b6fb0e7e3f155"
    retired = "institution:5396ea72656b4b19"
    assert entities[survivor]["institution_status"] == "active"
    assert entities[retired]["institution_status"] == "merged"
    # Both pre-audit records had a blank structured abbreviation; preserve it.
    assert entities[survivor]["abbreviation"] == entities[retired]["abbreviation"] == ""
    assert any(r["alias_name"] == "The Chinese University of Hong Kong" and r["institution_id"] == survivor for r in rows("institution_aliases"))
    location, = locations("ff4b6fb0e7e3f155")
    assert (float(location["lat"]), float(location["lon"])) == (22.4201838, 114.2079145)
    assert not any(r["institution_id"] == retired and r["mapping_status"] in {"active", "needs_review"} for r in rows("author_institution_mappings"))
    assert any(r["action"] == "mapping_change_confirmed" and r["previous_location_id"] == "location:c64f284c57cab3a3fe18" and r["location_id"] == location["location_id"] and r["paper_id"] == "curated:084e01a1a2191cb4c86a" for r in rows("institution_audit_log"))


def test_retired_location_history_warns_but_active_reference_is_an_error():
    institution = {"institution_id": "institution:campus", "canonical_name": "Example University", "institution_status": "active"}
    location = {"institution_id": institution["institution_id"], "location_id": "location:current"}
    mapping = {"mapping_id": "mapping:campus", "paper_id": "paper:1", "institution_id": institution["institution_id"], "mapping_status": "active", "location_id": location["location_id"]}
    audit = {"action": "mapping_change_confirmed", "paper_id": "paper:1", "mapping_id": mapping["mapping_id"], "previous_institution_id": institution["institution_id"], "institution_id": institution["institution_id"], "previous_location_id": "location:retired", "location_id": location["location_id"]}
    issues = []
    validate_institution_entities([institution], [mapping], [location], [], [], [audit], issues)
    assert any(issue.level == "WARNING" and "previous_location_id: location:retired" in issue.message for issue in issues)
    assert not any(issue.level == "ERROR" for issue in issues)
    issues = []
    validate_institution_entities([institution], [{**mapping, "location_id": "location:retired"}], [location], [], [], [audit], issues)
    assert any(issue.level == "ERROR" and "unknown mapping-specific location_id: location:retired" in issue.message for issue in issues)


def test_all_supported_manual_decisions_survive_with_original_identity():
    audit = json.loads((ROOT / "docs/manual_institution_location_audit_2026-08-27.json").read_text())["manual_audit_set"]
    assert len(audit) == 16
    assert len({r["institution"]["institution_id"] for r in audit}) == 15
    current = {r["location_id"]: r for r in rows("institution_locations")}
    preserved = [r for r in audit if r["independent_review"]["action"] == "preserve"]
    assert len(preserved) == 7
    for item in preserved:
        old = item["selected_location"]
        assert current[old["location_id"]] == old


def test_prior_supported_records_and_current_review_candidates_preserved():
    decisions = json.loads((ROOT / "docs/remaining_institution_location_audit_2026-08-27.json").read_text())
    payload = location_review_payload(
        mappings=load_mappings(), exclusions=PREDECESSOR_EXCLUSION_ROWS
    )
    # The historical cases remain traceable after the later manual review. The
    # Current pending rows are source-backed affiliations retained across the
    # later targeted paper audits; they intentionally have no guessed coordinates.
    assert payload["summary"]["pending_review"] == payload["summary"]["needs_coordinates"]
    # Six prior cases, Tier 1 affiliations, the Bangladesh address review, six
    # HIGH-evidence institutions plus IIT Patna, and the five new NORMAL-evidence
    # institutions plus two reused institutions that still lack coordinates.
    assert payload["summary"]["pending_review"] == 53
    for iid in ("institution:ea7b31bae9ab636d", "institution:251314027de80424"):
        assert any(r["institution_id"] == iid and r["review_status"] == "pending_review"
                   for r in payload["records"])
    for decision in decisions:
        iid = decision["institution_id"]
        records = [r for r in payload["records"] if r["institution_id"] == iid]
        if decision["result"] == "confirmed":
            assert all(r["review_status"] in {"confirmed", "alias_of_confirmed"} for r in records)
            location, = locations(iid.split(":")[1])
            assert location["location_id"] == decision["location_id"]
            assert valid_coordinates(location)
        elif iid == "institution:44469d661cb0034c":
            assert all(r["review_status"] == "confirmed" for r in records)
            assert markers(iid.split(":")[1])
        else:
            # These were pending in the dated historical snapshot and were
            # subsequently resolved by the authoritative manual review.
            assert all(r["review_status"] in {"confirmed", "alias_of_confirmed", "excluded"} for r in records)


def test_location_integrity_and_scoped_naming():
    locs = rows("institution_locations")
    assert all(valid_coordinates(r) for r in locs)
    assert len({r["location_id"] for r in locs}) == len(locs)
    assert len({normalized_location_key(r) for r in locs}) == len(locs)
    assert not any(r["country"] == "Türkiye" for r in locs)
    entities = {r["institution_id"]: r for r in rows("institutions")}
    assert entities["institution:bcd3d53e57c31275"]["canonical_name"] == "Mayachitra Inc."
    assert any(r["alias_name"] == "Mayachitra (United States)" and r["institution_id"] == "institution:bcd3d53e57c31275" for r in rows("institution_aliases"))
    assert entities["institution:1ee9da20656fd88b"]["canonical_name"] == "Politecnico di Milano"


@pytest.mark.parametrize("key", [
    "e07792f5cf49ebda", "2f2a5a5c1021efe4", "96dd3389141fcf35",
    "1f939a5a9221dfb6", "6ed8b18e4c077bfc",
])
def test_final_manual_location_pass_resolves_prior_actionable_cases(key):
    payload = location_review_payload(
        mappings=load_mappings(), exclusions=PREDECESSOR_EXCLUSION_ROWS
    )
    review, = [r for r in payload["records"] if r["institution_id"] == "institution:" + key]
    assert review["review_status"] in {"confirmed", "alias_of_confirmed"}
    assert review["location_status"] == "known"
    assert review["coordinate_status"] == "known"
    location, = locations(key)
    assert location["coordinate_status"] == "known"


def test_survey_kumoh_building_assignment_preserves_identity_and_author_group():
    import xml.etree.ElementTree as ET

    location, = locations("845768c6b2d48f68")
    marker, = markers("845768c6b2d48f68")
    assert location["city"] == "Gumi"
    assert marker["institution_authors"] == ["Thien Huynh-The"]
    mapping = next(r for r in rows("author_institution_mappings") if r["mapping_id"] == marker["mapping_id"])
    assert mapping["author_order"] == "5" and mapping["affiliation_order"] == "3"
    assert mapping["location_id"] == marker["location_id"] == location["location_id"]
    assert marker["institution_id"] == mapping["institution_id"] == location["institution_id"]
    osm = ET.parse(ROOT / "data/raw/evidence_resolution_2026-08-28/kumoh-campus.osm").getroot()
    nodes = {n.get("id"): (float(n.get("lon")), float(n.get("lat"))) for n in osm.findall("node")}
    building = next(w for w in osm.findall("way") if w.get("id") == "1518535866")
    assert {t.get("k"): t.get("v") for t in building.findall("tag")}["name"] == "산학협력관"
    points = [nodes[n.get("ref")] for n in building.findall("nd")]
    x, y = float(location["lon"]), float(location["lat"])
    crossings = sum((a[1] > y) != (b[1] > y) and x < (b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0]
                    for a, b in zip(points, points[1:]))
    assert crossings % 2 == 1  # Independently check the marker is inside the named building.
    assert (marker["lat"], marker["lon"]) == (y, x)


@pytest.mark.parametrize("key,author,city,evidence", [
    ("2f2a5a5c1021efe4", "Xiao Meng", "Guangzhou", "510006"),
    ("e07792f5cf49ebda", "Arjuna Flenner", "China Lake", "Point Mugu"),
    ("96dd3389141fcf35", "Digvijay Pandey", "Kanpur", "building"),
    ("1f939a5a9221dfb6", "Jing Liu", "Beijing", "2024"),
])
def test_final_public_textual_locations_preserve_evidence_after_manual_confirmation(key, author, city, evidence):
    iid = "institution:" + key
    review, = [r for r in rows("institution_location_review") if r["institution_id"] == iid]
    assert review["institution_authors"] == author
    assert review["suggested_city"] == city
    assert evidence in review["evidence_source"]
    assert review["review_status"] == "confirmed"
    assert review["location_status"] == "known"
    assert review["coordinate_status"] == "known"
    location, = locations(key)
    assert location["coordinate_status"] == "known"


def test_audited_legacy_centroid_markers_are_replaced_not_duplicated():
    audit = json.loads((ROOT / "docs/audited_marker_replacements_2026-08-27.json").read_text())
    exported = PREDECESSOR_MAP_RECORDS
    ids = {r["id"] for r in exported}
    assert len(audit["transitions"]) == 11
    for transition in audit["transitions"]:
        assert transition["previous_record_id"] not in ids
        assert any(r.get("mapping_id") == transition["mapping_id"] and r.get("location_id") == transition["location_id"] for r in exported)
